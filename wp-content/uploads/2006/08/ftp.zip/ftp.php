<?
/***************
 PHP Server Copy V .01
 
 Author: Shinda Singh
 website: www.shindasingh.com
 Release Date: August 2nd / 2006
 Last Build: August 2nd / 2006
 
Script is for general public use. Blah Blah...if you want to donate or feel that this script has saved you some flow then you can paypal it to shinda@gmail.com. If you modify if and call it your own, then more power to you. If you modify it copywrite it and call it your own, please don't sue me. Whatever else happens its all good.

USAGE: 

1) Fill out the FTP connection information

$ftp_server = "ftp.yourftpaddress.com";
$ftp_user_name = "ftp-username";
$ftp_user_pass = "ftp-password";
$ftp_dir = "/your/folder/here/";

2) Enter the url where you want to copy all files from ftp to.

$dirLocal = "/your/local/folder/goes/here/";

*** Make sure that the folder is writeable (CHMOD 777)..

3) Save and upload to your server.

4) Run ftp.php by visiting the url or running the cron job.
********************************
 
 
/*****************************************
           User Options
******************************************/		   
$ftp_server = "";
$ftp_user_name = "";
$ftp_user_pass = "";
$ftp_dir = ""; 

$dirLocal = ""; //Directory on Local

/************************************************
          DO NOT EDIT BELOW THIS POINT
*************************************************/
		  
// set up basic connection
$conn_id = ftp_connect($ftp_server);

// login with username and password
$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

$dir = $ftp_dir; //Directory on Remote

$contents = ftp_nlist($conn_id, $dir);
		
echo "Starting ".time()."<br>";

transferFiles($dir, $dirLocal);

function transferFiles($dirRemote, $dirLocal){
	global $conn_id;
	
	if ($conn_id != false){

		// get contents of the current directory
		$contents = ftp_nlist($conn_id, $dirRemote);
		
		foreach($contents as $file){
			$file2 = "$dirRemote/$file";
			$file3 = "$dirLocal/$file";
			
			if ( (ftp_size($conn_id, $file2) == -1) && !( ($file  == ".") || ($file == "..") ) ){ //Directory
				echo "<b>$file</b><br>";
				mkdir($file3);	//Make Folder
				transferFiles($file2,$file3);
			}
			elseif (ftp_size($conn_id, $file2) > 0) {
				echo "<i>$file</i>";
				
				//If File Exists Skip.
				if (file_exists($file3)){
					if (ftp_size($conn_id,$file2) == filesize($file3))
						echo "- skipped <br>";
					else {
						ftp_get($conn_id,$file3,$file2,FTP_BINARY,filesize($file3)/9);
						echo "- completed <br>";
					}
				}
				else {
					ftp_get($conn_id,$file3,$file2,FTP_BINARY);
					echo "<br>";
				}
				
			}
		}
	}
}
?> 